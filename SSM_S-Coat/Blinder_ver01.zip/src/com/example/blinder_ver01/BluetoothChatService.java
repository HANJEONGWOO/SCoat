// 1 2 3 4

package com.example.blinder_ver01;

import java.io.*;
import java.util.UUID;

import android.app.*;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothServerSocket;
import android.bluetooth.BluetoothSocket;
import android.content.*;
import android.graphics.*;
import android.os.*;
import android.telephony.*;
import android.util.Log;
import android.widget.*;

import android.speech.tts.*;
import android.speech.tts.TextToSpeech.OnInitListener;
/**
 * This class does all the work for setting up and managing Bluetooth
 * connections with other devices. It has a thread that listens for
 * incoming connections, a thread for connecting with a device, and a
 * thread for performing data transmissions when connected.
 */
// 1.연결입력을 기다리는 스레드
// 2.다른 장치와 연결을 위한 스레드
// 3.데이터 송 수신을 수행하는 스레드 - 내가 수정한 스레드

public class BluetoothChatService  implements OnInitListener {
    // Debugging
	
    private static final String TAG = "BluetoothChatService";
    private static final boolean D = true;

    // Name for the SDP record when creating server socket
    private static final String NAME_SECURE = "BluetoothChatSecure";
    private static final String NAME_INSECURE = "BluetoothChatInsecure";

    // Unique UUID for this application
    private static final UUID MY_UUID_SECURE =
    	UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
    	//UUID를 시리얼포트용으로 바꾸니 된다.
        //UUID.fromString("fa87c0d0-afac-11de-8a39-0800200c9a66");
    private static final UUID MY_UUID_INSECURE =
    	UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
        //UUID.fromString("8ce255c0-200a-11e0-ac64-0800200c9a66");

    public static final String STRSAVEPATH = Environment.getExternalStorageDirectory()+"/Blinder/";	//파일 경로
    
    // Member fields
    private final BluetoothAdapter mAdapter;
    private final Handler mHandler;
    private AcceptThread mSecureAcceptThread;	// 1. 연결 입력 스레드
    private AcceptThread mInsecureAcceptThread;	// 1. 연결 입력 스레드
    private ConnectThread mConnectThread;		// 2. 연결을 위한 스레드
    private ConnectedThread mConnectedThread;	// 3. 연결되어 데이터 송 수신을 위한 스레드
    private int mState;

    // Constants that indicate the current connection state
    public static final int STATE_NONE = 0;       // we're doing nothing
    public static final int STATE_LISTEN = 1;     // now listening for incoming connections
    public static final int STATE_CONNECTING = 2; // now initiating an outgoing connection
    public static final int STATE_CONNECTED = 3;  // now connected to a remote device
    
    
    Blinder_val B_val = new Blinder_val();
    Picture_val P_val = new Picture_val();
    
    TextToSpeech talker;
    
    
    /**
     * Constructor. Prepares a new BluetoothChat session.
     * @param context  The UI Activity Context
     * @param handler  A Handler to send messages back to the UI Activity
    */
    
    // 블루투스 초기화
    public BluetoothChatService(Context context, Handler handler)  {
        mAdapter = BluetoothAdapter.getDefaultAdapter();
        mState = STATE_NONE;
        mHandler = handler;
        talker = new TextToSpeech(context, (OnInitListener) this); //TTS 설정
    }

    /**
     * Set the current state of the chat connection
     * @param state  An integer defining the current connection state
     */
    // 상태 초기화
    private synchronized void setState(int state) {
        if (D) Log.d(TAG, "setState() " + mState + " -> " + state);
        mState = state;

        // Give the new state to the Handler so the UI Activity can update
        mHandler.obtainMessage(MainActivity.MESSAGE_STATE_CHANGE, state, -1).sendToTarget();
    }

    /**
     * Return the current connection state. */
    // 상태 얻어옴
    public synchronized int getState() {
        return mState;
    }

    /**
     * Start the chat service. Specifically start AcceptThread to begin a
     * session in listening (server) mode. Called by the Activity onResume() */
    // 채팅 서비스 시작 
    public synchronized void start() {
        if (D) Log.d(TAG, "start");

        // Cancel any thread attempting to make a connection
        // 연결시도하고 있는 기기가 있을 경우 스레드 취소
        if (mConnectThread != null) {mConnectThread.cancel(); mConnectThread = null;}

        // Cancel any thread currently running a connection
        // 현재 연결된 기기가 있을 경우 스레드 취소
        if (mConnectedThread != null) {mConnectedThread.cancel(); mConnectedThread = null;}

        setState(STATE_LISTEN);

        // Start the thread to listen on a BluetoothServerSocket
        if (mSecureAcceptThread == null) {
            mSecureAcceptThread = new AcceptThread(true);
            mSecureAcceptThread.start();
        }
        if (mInsecureAcceptThread == null) {
            mInsecureAcceptThread = new AcceptThread(false);
            mInsecureAcceptThread.start();
        }
    }

    /**
     * Start the ConnectThread to initiate a connection to a remote device.
     * @param device  The BluetoothDevice to connect
     * @param secure Socket Security type - Secure (true) , Insecure (false)
    */
    // 다른 기기와 연결을 시작할 때 연결 스레드를 시작한다.
    // 연결 타입 : 보안된 연결, 보안되지 않은 연결
    public synchronized void connect(BluetoothDevice device, boolean secure) {
        if (D) Log.d(TAG, "connect to: " + device);

        // Cancel any thread attempting to make a connection
        // 연결 요청중일때는 스레드를 종료시킨다.
        if (mState == STATE_CONNECTING) {
            if (mConnectThread != null) {mConnectThread.cancel(); mConnectThread = null;}
        }

        // Cancel any thread currently running a connection
        // 연결중일 때에도 연결스레드를 종료시킨다.
        if (mConnectedThread != null) {mConnectedThread.cancel(); mConnectedThread = null;}

        // Start the thread to connect with the given device
        // 주어진 장치가 있을경우 스레드를 시작한다.
        mConnectThread = new ConnectThread(device, secure);
        mConnectThread.start();
        setState(STATE_CONNECTING);
        
    }

    /**
     * Start the ConnectedThread to begin managing a Bluetooth connection
     * @param socket  The BluetoothSocket on which the connection was made
     * @param device  The BluetoothDevice that has been connected
     */
    // 블루투스 연결을 관리하기 위해 연결된 스레드를 시작한다.
    public synchronized void connected(BluetoothSocket socket, BluetoothDevice
            device, final String socketType) {
        if (D) Log.d(TAG, "connected, Socket Type:" + socketType);

        // Cancel the thread that completed the connection
        // ""
        if (mConnectThread != null) {mConnectThread.cancel(); mConnectThread = null;}

        // Cancel any thread currently running a connection
        // ""
        if (mConnectedThread != null) {mConnectedThread.cancel(); mConnectedThread = null;}

        // Cancel the accept thread because we only want to connect to one device
        // 우리는 하나의 디바이스와만 연결을 하기 때문에 연결된 후에는 액셉트 스레드를 종료시킨다.
        if (mSecureAcceptThread != null) {
            mSecureAcceptThread.cancel();
            mSecureAcceptThread = null;
        }
        if (mInsecureAcceptThread != null) {
            mInsecureAcceptThread.cancel();
            mInsecureAcceptThread = null;
        }

        // Start the thread to manage the connection and perform transmissions
        // 연결을 관리하고 데이터 이동을 위해 스레드를 시작한다.
        mConnectedThread = new ConnectedThread(socket, socketType);
        mConnectedThread.start();

        // Send the name of the connected device back to the UI Activity
        // 연결된 디바이스를 UI 액티비티로 보낸다?
        Message msg = mHandler.obtainMessage(MainActivity.MESSAGE_DEVICE_NAME);
        Bundle bundle = new Bundle();
        bundle.putString(MainActivity.DEVICE_NAME, device.getName());
        msg.setData(bundle);
        mHandler.sendMessage(msg);

        setState(STATE_CONNECTED);
    }

    /**
     * Stop all threads
     */
    public synchronized void stop() {
        if (D) Log.d(TAG, "stop");

        if (mConnectThread != null) {
            mConnectThread.cancel();
            mConnectThread = null;
        }

        if (mConnectedThread != null) {
            mConnectedThread.cancel();
            mConnectedThread = null;
        }

        if (mSecureAcceptThread != null) {
            mSecureAcceptThread.cancel();
            mSecureAcceptThread = null;
        }

        if (mInsecureAcceptThread != null) {
            mInsecureAcceptThread.cancel();
            mInsecureAcceptThread = null;
        }
        setState(STATE_NONE);
    }

    /**
     * Write to the ConnectedThread in an unsynchronized manner
     * @param out The bytes to write
     * @see ConnectedThread#write(byte[])
     */
    
    //라이트 메소드로 연결된 디바이스에 신호를 주는듯하다.
    public void write(byte[] out) {
        // Create temporary object
        ConnectedThread r;
        // Synchronize a copy of the ConnectedThread
        synchronized (this) {
            if (mState != STATE_CONNECTED) return;
            r = mConnectedThread;
        }
        // Perform the write unsynchronized
        r.write(out);
    }

    /**
     * Indicate that the connection attempt failed and notify the UI Activity.
     */
    private void connectionFailed() {
    	//BluetoothDevice tmp; 이거 삭제할것!!! 한줄만
        // Send a failure message back to the Activity
        Message msg = mHandler.obtainMessage(MainActivity.MESSAGE_TOAST);
        Bundle bundle = new Bundle();
        bundle.putString(MainActivity.TOAST, "Unable to connect device");
        msg.setData(bundle);
        mHandler.sendMessage(msg);

        // Start the service over to restart listening mode
        BluetoothChatService.this.start();
    }

    /**
     * Indicate that the connection was lost and notify the UI Activity.
     */
    private void connectionLost() {
        // Send a failure message back to the Activity
        Message msg = mHandler.obtainMessage(MainActivity.MESSAGE_TOAST);
        Bundle bundle = new Bundle();
        bundle.putString(MainActivity.TOAST, "Device connection was lost");
        msg.setData(bundle);
        mHandler.sendMessage(msg);

        // Start the service over to restart listening mode
        BluetoothChatService.this.start();
    }

    /**
     * This thread runs while listening for incoming connections. It behaves
     * like a server-side client. It runs until a connection is accepted
     * (or until cancelled).
     */
     
    //1번 연결대기 스레드 
    private class AcceptThread extends Thread {
        // The local server socket
        private final BluetoothServerSocket mmServerSocket;
        private String mSocketType;

        public AcceptThread(boolean secure) {
            BluetoothServerSocket tmp = null;
            mSocketType = secure ? "Secure":"Insecure";

            // Create a new listening server socket
            try {
                if (secure) {
                    tmp = mAdapter.listenUsingRfcommWithServiceRecord(NAME_SECURE,
                        MY_UUID_SECURE);
                } else {
                    tmp = mAdapter.listenUsingInsecureRfcommWithServiceRecord(
                            NAME_INSECURE, MY_UUID_INSECURE);
                }
            } catch (IOException e) {
                Log.e(TAG, "Socket Type: " + mSocketType + "listen() failed", e);
            }
            mmServerSocket = tmp;
        }
        
        // 소켓에 관한 데이터를 처리하는 스레드
        public void run() {
            if (D) Log.d(TAG, "Socket Type: " + mSocketType +
                    "BEGIN mAcceptThread" + this);
            setName("AcceptThread" + mSocketType);

            BluetoothSocket socket = null;

            // Listen to the server socket if we're not connected
            // 연결되지 않았을 때만 연결대기한다.
            while (mState != STATE_CONNECTED) {
                try {
                    // This is a blocking call and will only return on a
                    // successful connection or an exception
                    socket = mmServerSocket.accept();
                } catch (IOException e) {
                    Log.e(TAG, "Socket Type: " + mSocketType + "accept() failed", e);
                    break;
                }

                // If a connection was accepted
                // 커넥션이 허가되었을 때
                if (socket != null) {
                    synchronized (BluetoothChatService.this) {
                        switch (mState) {
                        case STATE_LISTEN:
                        case STATE_CONNECTING:
                            // Situation normal. Start the connected thread.
                            connected(socket, socket.getRemoteDevice(),
                                    mSocketType);
                            break;
                        case STATE_NONE:
                        case STATE_CONNECTED:
                            // Either not ready or already connected. Terminate new socket.
                            try {
                                socket.close();
                            } catch (IOException e) {
                                Log.e(TAG, "Could not close unwanted socket", e);
                            }
                            break;
                        }
                    }
                }
            }
            if (D) Log.i(TAG, "END mAcceptThread, socket Type: " + mSocketType);

        }

        public void cancel() {
            if (D) Log.d(TAG, "Socket Type" + mSocketType + "cancel " + this);
            try {
                mmServerSocket.close();
            } catch (IOException e) {
                Log.e(TAG, "Socket Type" + mSocketType + "close() of server failed", e);
            }
        }
    }


    /**
     * This thread runs while attempting to make an outgoing connection
     * with a device. It runs straight through; the connection either
     * succeeds or fails.
     */
    //2. 다른 장치와의 연결을 위한 스레드
    private class ConnectThread extends Thread {
        private final BluetoothSocket mmSocket;
        private final BluetoothDevice mmDevice;
        private String mSocketType;

        public ConnectThread(BluetoothDevice device, boolean secure) {
            mmDevice = device;
            BluetoothSocket tmp = null;
            mSocketType = secure ? "Secure" : "Insecure";

            // Get a BluetoothSocket for a connection with the
            // given BluetoothDevice
            
            try {
                if (secure) {
                    tmp = device.createRfcommSocketToServiceRecord(
                            MY_UUID_SECURE);
                } else {
                    tmp = device.createInsecureRfcommSocketToServiceRecord(
                            MY_UUID_INSECURE);
                }
            } catch (IOException e) {
                Log.e(TAG, "Socket Type: " + mSocketType + "create() failed", e);
            }
            mmSocket = tmp;
        }
        
        // 다른장치와 연결위한 스레드
        public void run() {
            Log.i(TAG, "BEGIN mConnectThread SocketType:" + mSocketType);
            setName("ConnectThread" + mSocketType);

            // Always cancel discovery because it will slow down a connection
            mAdapter.cancelDiscovery();

            // Make a connection to the BluetoothSocket
            try {
                // This is a blocking call and will only return on a
                // successful connection or an exception
                mmSocket.connect();
            } catch (IOException e) {
                // Close the socket
                try {
                    mmSocket.close();
                } catch (IOException e2) {
                    Log.e(TAG, "unable to close() " + mSocketType +
                            " socket during connection failure", e2);
                }
                connectionFailed();
                return;
            }

            // Reset the ConnectThread because we're done
            synchronized (BluetoothChatService.this) {
                mConnectThread = null;
            }

            // Start the connected thread
            connected(mmSocket, mmDevice, mSocketType);
        }

        public void cancel() {
            try {
                mmSocket.close();
            } catch (IOException e) {
                Log.e(TAG, "close() of connect " + mSocketType + " socket failed", e);
            }
        }
    }

    /**
     * This thread runs during a connection with a remote device.
     * It handles all incoming and outgoing transmissions.
     */
    // 3. 데이터 송 수신을 위한 스레드
    //이 스레드로 들어오고 나가는 데이터들을 다루는 듯 하다.
    private class ConnectedThread extends Thread {
        private final BluetoothSocket mmSocket;
        private final InputStream mmInStream;
        private final OutputStream mmOutStream;

        public ConnectedThread(BluetoothSocket socket, String socketType) {
            Log.d(TAG, "create ConnectedThread: " + socketType);
            mmSocket = socket;
            InputStream tmpIn = null;
            OutputStream tmpOut = null;

            // Get the BluetoothSocket input and output streams
            // 입력 출력 스트림을 얻는다.
            try {
                tmpIn = socket.getInputStream();
                tmpOut = socket.getOutputStream();
            } catch (IOException e) {
                Log.e(TAG, "temp sockets not created", e);
            }

            mmInStream = tmpIn;
            mmOutStream = tmpOut;
        }

        public void run() {
            Log.i(TAG, "BEGIN mConnectedThread");
            byte[] buffer = new byte[20000];
            int bytes;
            String sendTo = B_val.data_protecter_pn;
            SmsManager smsManager = SmsManager.getDefault();
            // Keep listening to the InputStream while connected
            int i=0;
            
            while (true) {
                try {
                    // Read from the InputStream
                    bytes = mmInStream.read(buffer);
                    // 캐치!!! 여기 바이트가 읽는 바이트다.!!!!

                    if(buffer[0] == 'e' && buffer[1] == 'm' && buffer[2] == 'e' && buffer[3] == 'r' &&
                    		buffer[4] == 'g' && buffer[5] == 'e' && buffer[6] == 'n' && buffer[7] == 'c' && buffer[8] == 'y')
                    {
                    	String myMessage = 
                    			"!" +  B_val.latitude + "," + B_val.longitude + B_val.data_protecter_name + "님에게 " + B_val.data_blinder_name + "님이 위험메시지";
                    	
                    	smsManager.sendTextMessage(sendTo, null, myMessage, null, null);
                    	Log.d(TAG, "send_message");
                    	
                    	say("메시지 전송 완료!");
                    	
                    }	//위험 메시지
                    else if(buffer[0] == 'r' && buffer[1] == 'e' && buffer[2] == 'l' && buffer[3] == 'e' &&
                    		buffer[4] == 'a' && buffer[5] == 's' && buffer[6] == 'e')
                    {
                    	String myMessage = B_val.data_blinder_name + "님이 위험메시지를 해제하였습니다.";
                    	
                    	smsManager.sendTextMessage(sendTo,  null,  myMessage, null, null);
                    	Log.d(TAG, "stop_message");
                    	say("메시지 전송 완료!");
                    }	//위험 메시지 해제
                    else if(buffer[0] == (byte) 0xff && buffer[1] == (byte) 0xd8)
                    {
                    	P_val.i = 0;	//입력 횟수 초기화
                    	for(int j=0; j<bytes; j++)
                    	{
                    		P_val.picture_buffer[P_val.i] = buffer[j];	//첫번째 배열 입력
                    		P_val.i++;	//증가
                    	}
                    	P_val.start_flag = 1;	//스타트 플래그 1 설정 - 시작하겠다는 뜻
                    }
                    else if(P_val.start_flag == 1)	//스타트 플래그가 1일 경우 == 시작햇다는 뜻
                    {
                    	if(P_val.complete == 1)	{	
                    		P_val.complete = 0;		//완료 플래그 0으로 설정
                    	}
                    	
                    	for(int j=0; j<bytes; j++)	
                    	{
                    		P_val.picture_buffer[P_val.i] = buffer[j];	//받고
                    		
                    		if(P_val.i > 3000 && P_val.picture_buffer[P_val.i-1] == (byte)0xff && P_val.picture_buffer[P_val.i] == (byte)0xd9)
                    		{
                    			P_val.start_flag = 0;
                    			P_val.complete = 1;
                    			say("사진 촬영 완료!");
                    			//startActivity();
                    			//.performClick();
                    			
                    			Bitmap bmimg = byteArrayToBitmap(P_val.picture_buffer);
                				String fileName = String.valueOf(System.currentTimeMillis()) + ".png";
                				//파일의 이름이 같을경우 계속 중복생성이 되므로 시간을 이용하여 중복생성 피한다
                				
                				//Blinder 폴더에 같이 저장함
                				File file1 = new File(STRSAVEPATH , fileName);	//파일 생성
                							OutputStream out = null;
                							try	{
                								file1.createNewFile();
                								out = new FileOutputStream(file1);
                								bmimg.compress(Bitmap.CompressFormat.PNG, 100, out);
                								//bmimg를 압축시키겠다는 뜻
                								out.close();
                							} catch(Exception e)	{
                								e.printStackTrace();
                							}
                    		}	//종료 설정
                    		
                    		P_val.i++;	//1증가 시킴
                    	}
                    	                    	
                    	


                    	//String str = new String(P_val.picture_buffer);
           
                    	//startActivity(intent); //스타트 액티비티 해서 뭐 하는게 있다고 함
                    	//System.out.println("Camera receive");
                    	//System.out.println(str);
                    	//System.out.println("P_val.i : " + P_val.i);
                    	//System.out.println("P_val.picture_buffer.length : " + P_val.picture_buffer.length);
                    }
                    
                    
                    /*
                    else if(buffer[0] == 0xff && buffer[1] == 0xd8)
                    {
                    	P_val.start_flag = 1;
                    	P_val.picture_buffer[P_val.i++] = buffer[0];
                    	P_val.picture_buffer[P_val.i++] = buffer[1];
                    	Log.d(TAG, "start");
                    	System.out.println("Camera Start!!!");
                    }	//카메라 시작! 인데 시작이 안된다...
                    else if(buffer[i] == 0xff && buffer[i+1] == 0xd9)
                    {
                    	P_val.picture_size = P_val.i;
                    	
                    	Log.d(TAG, "Count : " + P_val.i);
                    	P_val.i = 0; i = 0;
                    	P_val.start_flag = 0;
                    	Log.d(TAG, "end");
                    	System.out.println("Camera End!!!");
                    }	//카메라 끝! 인데 끝도 안됨
                    else if(P_val.start_flag == 1)
                    {
                    	Log.d(TAG,"START PICTURE!");
                    	P_val.picture_buffer[P_val.i] = buffer[P_val.i];
                    	P_val.i++; i++;
                    	Log.d(TAG, "start_flag");
                    	System.out.println("Camera middle!!!");
                    }	//중간 값들
					*/
                    
                    // Send the obtained bytes to the UI Activity
                    mHandler.obtainMessage(MainActivity.MESSAGE_READ, bytes, -1, buffer)
                            .sendToTarget();
                    //mHandler.obtainMessage(MainActivity.MESSAGE_READ, bytes, -1, buffer)
                    //.sendToTarget();
                    //
                    //
                    //
                } catch (IOException e) {
                    Log.e(TAG, "disconnected", e);
                    connectionLost();
                    // Start the service over to restart listening mode
                    BluetoothChatService.this.start();
                    break;
                }
            }
        }

        /**
         * Write to the connected OutStream.
         * @param buffer  The bytes to write
         */
        public void write(byte[] buffer) {
            try {
                mmOutStream.write(buffer);

                // Share the sent message back to the UI Activity
                mHandler.obtainMessage(MainActivity.MESSAGE_WRITE, -1, -1, buffer)
                        .sendToTarget();
            } catch (IOException e) {
                Log.e(TAG, "Exception during write", e);
            }
        }

        public void cancel() {
            try {
                mmSocket.close();
            } catch (IOException e) {
                Log.e(TAG, "close() of connect socket failed", e);
            }
        }
    }
    
    public Bitmap byteArrayToBitmap( byte[] $byteArray ) {  
       Bitmap bitmap = BitmapFactory.decodeByteArray( $byteArray, 0, $byteArray.length ) ;  
       return bitmap ;  
    }
    

	public void say(String text2say)	{
		talker.speak(text2say,  TextToSpeech.QUEUE_FLUSH,  null);
	}

	public void onInit(int status)	{
		//say("안녕하세요 반갑습니다.");
	}
	
	public void sleep(int time){
		try {
			Thread.sleep(time);
		} catch (InterruptedException e) { }
	}	//sleep()함수
}

