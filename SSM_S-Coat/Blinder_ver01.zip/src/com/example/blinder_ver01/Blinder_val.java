package com.example.blinder_ver01;

import com.example.blinder_ver01.R.string;



public class Blinder_val {
	public static double latitude;
	public static double longitude;
	
	public static String data_blinder_name;	//장애인 이름
	public static String data_protecter_name;	//보호자 이름
	public static String data_protecter_pn;	//보호자 번호
	
	public static char[] blinder_name = new char[3];
	public static char[] protecter_name = new char[3];
	public static char[] protecter_pn = new char[11];
}
