package com.example.blinder_ver01;

import android.content.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.widget.*;

public class Picture_val {
	public static byte[] picture_buffer = new byte[10000];
	public static byte[] end_byte = new byte[2];
	public static int i;
	public static int picture_size;
	
	public static int complete = 1;
	
	public static int start_flag = 0;
		
}
