/** Automatically generated file. DO NOT MODIFY */
package com.example.blinder_ver01;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}