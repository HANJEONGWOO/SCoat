package com.example.protecter_ver01;

public class Protecter_val {
	static double blinder_latitude;
	static double blinder_longitude;
	
	static int quit_flag;
}
