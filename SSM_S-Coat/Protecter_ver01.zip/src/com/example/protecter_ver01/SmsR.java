// 1

package com.example.protecter_ver01;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.telephony.SmsMessage;
import android.util.Log;
import android.widget.Toast;

import android.app.*;
import android.os.Bundle;

public class SmsR extends BroadcastReceiver {
	
	private static final String LOG_TAG = "SmsR";
	private static final String ACTION = "android.provider.Telephony.SMS_RECEIVED";
    
	Protecter_val P_val = new Protecter_val();
	
	String phone_number;
	char[] lati_c = new char[100];
	char[] lati = new char[10];
	char[] long_c = new char[100];
	char[] longi = new char[11];

	int j;
	
	int count=1;	//카운트는 첫번째 1부터 시작
	
	@Override
	public void onReceive(Context context, Intent intent)	{
		if(intent.getAction().equals(ACTION))	{
			StringBuilder ab = new StringBuilder();
			Bundle bundle = intent.getExtras();
			
			if(bundle != null)	{
				Object[] pdusObj = (Object[]) bundle.get("pdus");
				SmsMessage[] messages = new SmsMessage[pdusObj.length];
				
				for(int i=0; i<pdusObj.length; i++)	{
					messages[i] = SmsMessage.createFromPdu((byte[])pdusObj[i]);
					//ab.append("Received compressed SMS\n FROM ");
					//ab.append(messages[i].getDisplayOriginatingAddress());
					//ab.append("--Message--");
					ab.append(messages[i].getDisplayMessageBody());						
				}
				
				lati_c = ab.toString().toCharArray();
				long_c = ab.toString().toCharArray();
				System.out.println(ab.toString());
				
				//System.out.println("lati_c : " + String.valueOf(lati_c));
				//System.out.println("longi_c : " + String.valueOf(long_c));
			}
			
			if(lati_c[0] != '!')	{
				P_val.quit_flag = 1;	//만약 시작이 느낌표가 아니라면 플래그 1 설정
				return;
			} 
			/*
			try	{
				Thread.sleep(2000);		//2초 딜레이
			} catch(InterruptedException ignore)	{}
			*/
			
			for(int i=0; i<10; i++)	{
				if(lati_c[count] >= '0' && lati_c[count] <= '9' || lati_c[count] == '.')
				{
					lati[i] = lati_c[count];	//위도 파싱
					count++;
				}
				else if(lati_c[count] == ',')	{//따움표 나오면 나가기
					break;
				}
				System.out.println(count);
			}
			count++;	//더하는게 맞다 따움표다
			
			for(int i=0; i<11; i++)	{
				if(long_c[count] >= '0' && long_c[count] <= '9' || long_c[count] == '.')
				{
					longi[i] = long_c[count]; //경도 파싱
					count++;
				}
				else	//숫자가 아니면 무조건 나가기
					break;
			}
			
				//System.out.println("- lati : " + String.valueOf(lati));
				//System.out.println("- longi : " + String.valueOf(longi));
			
			try	{	//Try-catch를 이용하여 오류를 없앤다
			P_val.blinder_latitude = Double.parseDouble(String.valueOf(lati));	//오류나는 곳이니 조심
			P_val.blinder_longitude = Double.parseDouble(String.valueOf(longi)); //String.valueOf를 쓰니 된다.
			}
			catch(Exception E)	{
				Toast.makeText(context, "위도 경도가 정확하지 않아 나타낼 수 없습니다.", Toast.LENGTH_LONG).show();
				//조심조심
			}
			
			
			//System.out.println(P_val.blinder_latitude);
			//System.out.println(P_val.blinder_longitude);
			Log.i(LOG_TAG, "[SMSApp]onReceiveIntent: " + ab);
			Toast.makeText(context,  ab.toString(), Toast.LENGTH_LONG).show();
			
			//Start The MainActivity
			Intent i = new Intent(context, MainActivity.class);
			i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
			context.startActivity(i);
		}
	}
}
