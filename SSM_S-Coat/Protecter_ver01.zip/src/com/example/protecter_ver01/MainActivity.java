// 1 

package com.example.protecter_ver01;

import android.location.*;
import android.os.Bundle;
import android.app.*;
import android.content.*;
import android.content.DialogInterface.OnClickListener;
import android.util.*;
import android.view.Menu;

import com.google.android.gms.internal.v;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.GoogleMap.InfoWindowAdapter;
import com.google.android.gms.maps.GoogleMap.OnInfoWindowClickListener;
import com.google.android.gms.maps.GoogleMap.OnMarkerClickListener;
import com.google.android.gms.maps.GoogleMap.OnMyLocationChangeListener;
import com.google.android.gms.maps.MapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;

public class MainActivity extends Activity {
	
    private static final String TAG = "BluetoothChat";
    
	GoogleMap map;	//1) 현재 위치로 맵을 가져오는 변수
	LocationManager manager;
	MyLocationListener listener;

	String provider;
	Protecter_val P_val = new Protecter_val();
	
	float[]distance = new float[2];	//float 형태의 사이즈 2배열 생성
	float actual_distance;	//실제 거리 값을 담을 변수
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		map = ((MapFragment) getFragmentManager().findFragmentById(R.id.map)).getMap();
		//1)맵을 읽어옴
		
		// 여기 GPS 만 했다하면 죽어버리네요 - 요놈 잡았다! (MyLocationListener 를 선언해주니 잡음)
		manager = (LocationManager)getSystemService(Context.LOCATION_SERVICE);
		
		if(manager.isProviderEnabled(LocationManager.NETWORK_PROVIDER))
		{
			provider = LocationManager.NETWORK_PROVIDER;
			Log.d(TAG, "NETWORK_PROVIDER CALL");
		}
		else if(manager.isProviderEnabled(LocationManager.GPS_PROVIDER))
		{
			provider = LocationManager.GPS_PROVIDER;
			Log.d(TAG, "GPS_PROVIDER CALL");
		}
		
		Location location = manager.getLastKnownLocation(provider);
		// 두 프로바이더 중 하나의 프로바이더를 선택
			
			//gps 
			CameraPosition cameraPosition = new CameraPosition.Builder()
			.target(new LatLng(P_val.blinder_latitude, P_val.blinder_longitude))	//여기
			.zoom(13)                   
			.bearing(0)                
			.tilt(0)                 
			.build();  
			
			//location.getLatitude(),location.getLongitude()

			LatLng latlng_p = new LatLng(location.getLatitude(), location.getLongitude());
			LatLng latlng_b = new LatLng(P_val.blinder_latitude, P_val.blinder_longitude);
			map.animateCamera(CameraUpdateFactory.newCameraPosition(cameraPosition));

			map.addMarker(new MarkerOptions().icon(BitmapDescriptorFactory.fromResource(R.drawable.blinder)).
					position(latlng_b).title("시각장애인").snippet("위도 : " + location.getLatitude() + "\r\n경도 : " + location.getLongitude() ));	//시각장애인 마커
			
			Location.distanceBetween(location.getLatitude(), location.getLongitude(), P_val.blinder_latitude, P_val.blinder_longitude, distance);
			actual_distance = distance[0];	//거리구하기
			String strnum = String.format("%.2f", actual_distance);	//5자리까지만 보여주기

			map.addMarker(new MarkerOptions().icon(BitmapDescriptorFactory.fromResource(R.drawable.protecter)).position(latlng_p).title("보호자").snippet("현재 지점과의 거리 : " + strnum + "km"));
			// 나의 위치 마커

			
			map.setOnMyLocationChangeListener((OnMyLocationChangeListener) listener);	//
			
			listener = new MyLocationListener();	//
			listener.onLocationChanged(location);	//
			
			manager.requestLocationUpdates(provider,0,0, listener);	//
			
			if(P_val.quit_flag == 1)	{
				finish();
			}
	

	
	}
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}
	
	public class MyLocationListener implements LocationListener{
		public MyLocationListener()
		{
			Log.e("LocationListener","LocationListener Called!!!");
		}
		public void onLocationChanged(Location location)
		{
			Log.e("onLocationChanged","Changing");	
		}
		public void onProviderDisabled(String provider){}
		public void onProviderEnabled(String provider) {}
		public void onStatusChanged(String provider, int status, Bundle extras){}
	}//

}
